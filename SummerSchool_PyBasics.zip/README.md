# SummerSchoolUEF_2023
 Python Basic
